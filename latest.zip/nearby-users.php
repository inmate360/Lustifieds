<?php
session_start();
require_once 'config/database.php';
require_once 'classes/LocationService.php';
require_once 'includes/maintenance_check.php';

if(!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit();
}

$database = new Database();
$db = $database->getConnection();

if(checkMaintenanceMode($db)) {
    header('Location: maintenance.php');
    exit();
}

$locationService = new LocationService($db);

// Get user's current location
$query = "SELECT current_latitude, current_longitude, search_radius, show_distance 
          FROM users WHERE id = :user_id LIMIT 1";
$stmt = $db->prepare($query);
$stmt->bindParam(':user_id', $_SESSION['user_id']);
$stmt->execute();
$current_user = $stmt->fetch();

$has_location = !empty($current_user['current_latitude']);

include 'views/header.php';
?>

<link rel="stylesheet" href="/assets/css/dark-blue-theme.css">
<link rel="stylesheet" href="/assets/css/light-theme.css">

<style>
.location-header {
    background: linear-gradient(135deg, #4267F5, #1D9BF0);
    padding: 2rem;
    border-radius: 15px;
    margin-bottom: 2rem;
    text-align: center;
    color: white;
}

.location-controls {
    display: flex;
    gap: 1rem;
    justify-content: center;
    align-items: center;
    margin-top: 1rem;
    flex-wrap: wrap;
}

.radius-slider {
    width: 300px;
    margin: 0 1rem;
}

.users-grid {
    display: grid;
    grid-template-columns: repeat(auto-fill, minmax(320px, 1fr));
    gap: 2rem;
    margin-top: 2rem;
}

/* Modern Card Styles from UIverse */
.user-card {
    position: relative;
    width: 100%;
    height: 400px;
    background: linear-gradient(-45deg, #1e3a8a 0%, #2563eb 100%);
    border-radius: 20px;
    display: flex;
    align-items: center;
    justify-content: center;
    overflow: hidden;
    transition: all 0.6s cubic-bezier(0.23, 1, 0.320, 1);
    cursor: pointer;
}

.user-card:hover {
    transform: rotate(-2deg) scale(1.05);
    box-shadow: 0 20px 40px rgba(37, 99, 235, 0.4);
}

.user-card::before {
    content: '';
    position: absolute;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background: linear-gradient(135deg, rgba(66, 103, 245, 0.3), rgba(29, 155, 240, 0.3));
    opacity: 0;
    transition: opacity 0.6s;
}

.user-card:hover::before {
    opacity: 1;
}

.user-card-content {
    position: relative;
    display: flex;
    flex-direction: column;
    align-items: center;
    gap: 1.5rem;
    padding: 2rem;
    z-index: 2;
    transition: transform 0.6s;
}

.user-card:hover .user-card-content {
    transform: translateY(-10px);
}

.user-avatar-wrapper {
    position: relative;
    width: 120px;
    height: 120px;
}

.user-avatar {
    width: 120px;
    height: 120px;
    border-radius: 50%;
    background: linear-gradient(135deg, rgba(255, 255, 255, 0.2), rgba(255, 255, 255, 0.1));
    border: 4px solid rgba(255, 255, 255, 0.3);
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 3.5rem;
    position: relative;
    backdrop-filter: blur(10px);
    box-shadow: 0 8px 32px rgba(0, 0, 0, 0.3);
    transition: transform 0.6s;
}

.user-card:hover .user-avatar {
    transform: scale(1.1) rotate(5deg);
}

.online-badge {
    position: absolute;
    bottom: 5px;
    right: 5px;
    width: 24px;
    height: 24px;
    background: #10b981;
    border: 4px solid rgba(255, 255, 255, 0.3);
    border-radius: 50%;
    box-shadow: 0 0 20px rgba(16, 185, 129, 0.6);
    animation: pulse 2s infinite;
}

@keyframes pulse {
    0%, 100% {
        box-shadow: 0 0 20px rgba(16, 185, 129, 0.6);
    }
    50% {
        box-shadow: 0 0 30px rgba(16, 185, 129, 0.9);
    }
}

.distance-badge {
    position: absolute;
    top: 1rem;
    right: 1rem;
    background: rgba(255, 255, 255, 0.15);
    backdrop-filter: blur(10px);
    padding: 0.5rem 1rem;
    border-radius: 20px;
    font-size: 0.9rem;
    color: white;
    font-weight: 600;
    border: 1px solid rgba(255, 255, 255, 0.2);
    z-index: 3;
}

.user-info {
    text-align: center;
    color: white;
}

.user-name {
    font-size: 1.8rem;
    font-weight: 700;
    margin-bottom: 0.5rem;
    color: white;
    text-shadow: 0 2px 10px rgba(0, 0, 0, 0.3);
}

.user-status {
    font-size: 1rem;
    opacity: 0.9;
    margin-bottom: 0.5rem;
}

.user-meta {
    font-size: 0.9rem;
    opacity: 0.8;
}

.user-actions {
    display: flex;
    gap: 0.75rem;
    margin-top: 1rem;
    opacity: 0;
    transform: translateY(20px);
    transition: all 0.6s;
}

.user-card:hover .user-actions {
    opacity: 1;
    transform: translateY(0);
}

.action-btn {
    padding: 0.75rem 1.5rem;
    background: rgba(255, 255, 255, 0.2);
    backdrop-filter: blur(10px);
    border: 1px solid rgba(255, 255, 255, 0.3);
    border-radius: 25px;
    color: white;
    text-decoration: none;
    font-weight: 600;
    transition: all 0.3s;
    display: flex;
    align-items: center;
    gap: 0.5rem;
}

.action-btn:hover {
    background: rgba(255, 255, 255, 0.3);
    transform: translateY(-2px);
    box-shadow: 0 4px 15px rgba(255, 255, 255, 0.2);
}

.filter-bar {
    background: var(--card-bg);
    border: 2px solid var(--border-color);
    border-radius: 12px;
    padding: 1.5rem;
    margin-bottom: 2rem;
    display: flex;
    gap: 1rem;
    align-items: center;
    flex-wrap: wrap;
}

.no-location {
    text-align: center;
    padding: 4rem 2rem;
    background: var(--card-bg);
    border: 2px solid var(--border-color);
    border-radius: 15px;
}

.location-permission {
    background: rgba(66, 103, 245, 0.1);
    border: 2px solid var(--primary-blue);
    border-radius: 15px;
    padding: 2rem;
    margin: 2rem 0;
    text-align: center;
}

/* Modal Styles */
.modal-overlay {
    display: none;
    position: fixed;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    background: rgba(0, 0, 0, 0.85);
    z-index: 9999;
    backdrop-filter: blur(5px);
    animation: fadeIn 0.3s ease;
}

.modal-overlay.active {
    display: flex;
    align-items: center;
    justify-content: center;
    padding: 20px;
}

.modal-content {
    background: linear-gradient(135deg, #1e3a8a 0%, #2563eb 100%);
    border-radius: 24px;
    max-width: 600px;
    width: 100%;
    max-height: 90vh;
    overflow-y: auto;
    position: relative;
    box-shadow: 0 20px 60px rgba(0, 0, 0, 0.5);
    animation: slideUp 0.4s ease;
}

.modal-header {
    padding: 2rem;
    border-bottom: 2px solid rgba(255, 255, 255, 0.1);
    position: sticky;
    top: 0;
    background: linear-gradient(135deg, #1e3a8a 0%, #1e40af 100%);
    backdrop-filter: blur(10px);
    z-index: 1;
}

.modal-close {
    position: absolute;
    top: 1rem;
    right: 1rem;
    background: rgba(255, 255, 255, 0.15);
    border: none;
    width: 40px;
    height: 40px;
    border-radius: 50%;
    font-size: 1.5rem;
    color: white;
    cursor: pointer;
    transition: all 0.3s;
    display: flex;
    align-items: center;
    justify-content: center;
}

.modal-close:hover {
    background: rgba(255, 255, 255, 0.25);
    transform: rotate(90deg);
}

.modal-user-avatar {
    width: 100px;
    height: 100px;
    border-radius: 50%;
    background: linear-gradient(135deg, rgba(255, 255, 255, 0.2), rgba(255, 255, 255, 0.1));
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 3rem;
    margin: 0 auto 1rem;
    border: 3px solid rgba(255, 255, 255, 0.3);
    position: relative;
}

.modal-user-name {
    font-size: 2rem;
    font-weight: 700;
    text-align: center;
    color: white;
    text-shadow: 0 2px 10px rgba(0, 0, 0, 0.3);
    margin-bottom: 0.5rem;
}

.modal-user-status {
    text-align: center;
    color: rgba(255, 255, 255, 0.9);
    font-size: 1rem;
    margin-bottom: 1rem;
}

.modal-body {
    padding: 2rem;
}

.modal-section {
    background: rgba(255, 255, 255, 0.1);
    backdrop-filter: blur(10px);
    border-radius: 15px;
    padding: 1.5rem;
    margin-bottom: 1.5rem;
    border: 1px solid rgba(255, 255, 255, 0.15);
}

.modal-section h3 {
    color: white;
    font-size: 1.2rem;
    margin-bottom: 1rem;
    display: flex;
    align-items: center;
    gap: 0.5rem;
}

.modal-info-item {
    display: flex;
    align-items: center;
    gap: 0.75rem;
    padding: 0.75rem 0;
    border-bottom: 1px solid rgba(255, 255, 255, 0.1);
    color: rgba(255, 255, 255, 0.95);
}

.modal-info-item:last-child {
    border-bottom: none;
}

.modal-info-icon {
    font-size: 1.2rem;
    opacity: 0.9;
}

.modal-info-label {
    font-weight: 600;
    color: white;
    min-width: 100px;
}

.modal-info-value {
    color: rgba(255, 255, 255, 0.9);
    flex: 1;
}

.modal-distance {
    background: rgba(255, 255, 255, 0.15);
    padding: 1rem 1.5rem;
    border-radius: 12px;
    text-align: center;
    margin-bottom: 1.5rem;
}

.modal-distance-value {
    font-size: 2rem;
    font-weight: 700;
    color: white;
    text-shadow: 0 2px 10px rgba(0, 0, 0, 0.3);
}

.modal-distance-label {
    color: rgba(255, 255, 255, 0.9);
    font-size: 0.9rem;
    margin-top: 0.25rem;
}

.modal-actions {
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 1rem;
    padding: 0 2rem 2rem;
}

.modal-btn {
    padding: 1rem 2rem;
    border-radius: 12px;
    border: none;
    font-weight: 600;
    font-size: 1rem;
    cursor: pointer;
    transition: all 0.3s;
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 0.5rem;
}

.modal-btn-primary {
    background: white;
    color: #1e3a8a;
}

.modal-btn-primary:hover {
    background: #f1f5f9;
    transform: translateY(-2px);
    box-shadow: 0 8px 20px rgba(255, 255, 255, 0.2);
}

.modal-btn-secondary {
    background: rgba(255, 255, 255, 0.15);
    color: white;
    border: 2px solid rgba(255, 255, 255, 0.3);
}

.modal-btn-secondary:hover {
    background: rgba(255, 255, 255, 0.25);
    border-color: rgba(255, 255, 255, 0.5);
}

@keyframes fadeIn {
    from { opacity: 0; }
    to { opacity: 1; }
}

@keyframes slideUp {
    from {
        opacity: 0;
        transform: translateY(30px) scale(0.95);
    }
    to {
        opacity: 1;
        transform: translateY(0) scale(1);
    }
}

@media (max-width: 768px) {
    .users-grid {
        grid-template-columns: 1fr;
    }
    
    .user-card {
        height: 380px;
    }
    
    .modal-content {
        max-height: 95vh;
        border-radius: 20px 20px 0 0;
    }
    
    .modal-actions {
        grid-template-columns: 1fr;
    }
}
</style>

<div class="page-content">
    <div class="container">
        <div class="location-header">
            <h1 style="margin-bottom: 0.5rem;">📍 Nearby Users</h1>
            <p style="opacity: 0.9;">Discover people close to you</p>
            
            <div class="location-controls">
                <button class="btn-primary" onclick="requestLocation()" id="locationBtn">
                    📍 Update My Location
                </button>
                
                <div style="display: flex; align-items: center; gap: 1rem;">
                    <label style="color: white;">Search Radius:</label>
                    <input type="range" class="radius-slider" 
                           id="radiusSlider" 
                           min="5" max="100" step="5" 
                           value="<?php echo $current_user['search_radius'] ?? 50; ?>"
                           oninput="updateRadius(this.value)">
                    <span id="radiusValue" style="color: white; font-weight: 600; min-width: 60px;">
                        <?php echo $current_user['search_radius'] ?? 50; ?> km
                    </span>
                </div>
                
                <label style="color: white; display: flex; align-items: center; gap: 0.5rem;">
                    <input type="checkbox" 
                           id="showDistanceToggle"
                           <?php echo $current_user['show_distance'] ? 'checked' : ''; ?>
                           onchange="toggleDistanceVisibility(this.checked)">
                    Show my distance to others
                </label>
            </div>
        </div>

        <?php if(!$has_location): ?>
        <div class="no-location">
            <div style="font-size: 5rem; margin-bottom: 1rem;">📍</div>
            <h2 style="margin-bottom: 1rem;">Location Not Set</h2>
            <p style="color: var(--text-gray); margin-bottom: 2rem;">
                Enable location access to discover nearby users and see who's close to you
            </p>
            
            <div class="location-permission">
                <h3 style="color: var(--primary-blue); margin-bottom: 1rem;">How It Works</h3>
                <ol style="text-align: left; max-width: 500px; margin: 0 auto; line-height: 2; color: var(--text-gray);">
                    <li>Click "Update My Location" button</li>
                    <li>Allow location access in your browser</li>
                    <li>We'll show you nearby users within your search radius</li>
                    <li>You control your distance visibility settings</li>
                </ol>
            </div>
            
            <button class="btn-primary" style="font-size: 1.1rem; padding: 1rem 2rem; margin-top: 2rem;" 
                    onclick="requestLocation()">
                📍 Enable Location Access
            </button>
        </div>
        <?php else: ?>
        
        <!-- Filters -->
        <div class="filter-bar">
            <label style="color: var(--text-white); display: flex; align-items: center; gap: 0.5rem;">
                <span>🔍</span>
                <input type="text" 
                       id="searchUsers" 
                       placeholder="Search users..." 
                       style="min-width: 250px;">
            </label>
            
            <select id="genderFilter" onchange="loadNearbyUsers()">
                <option value="">All Genders</option>
                <option value="male">Male</option>
                <option value="female">Female</option>
                <option value="other">Other</option>
            </select>
            
            <select id="onlineFilter" onchange="loadNearbyUsers()">
                <option value="">All Users</option>
                <option value="online">Online Now</option>
                <option value="recent">Active Recently</option>
            </select>
            
            <select id="sortBy" onchange="loadNearbyUsers()">
                <option value="distance">Distance (Nearest)</option>
                <option value="recent">Recently Active</option>
                <option value="newest">Newest Members</option>
            </select>
        </div>
        
        <!-- Loading State -->
        <div id="loadingState" style="text-align: center; padding: 3rem; display: none;">
            <div style="font-size: 3rem; margin-bottom: 1rem;">⏳</div>
            <p style="color: var(--text-gray);">Finding nearby users...</p>
        </div>
        
        <!-- Results Count -->
        <div id="resultsCount" style="margin-bottom: 1rem; color: var(--text-gray);"></div>
        
        <!-- Users Grid -->
        <div class="users-grid" id="usersGrid">
            <!-- Users will be loaded here -->
        </div>
        
        <!-- No Results -->
        <div id="noResults" style="display: none; text-align: center; padding: 3rem; background: var(--card-bg); border: 2px solid var(--border-color); border-radius: 15px;">
            <div style="font-size: 4rem; margin-bottom: 1rem;">🔍</div>
            <h3>No Nearby Users Found</h3>
            <p style="color: var(--text-gray); margin-top: 0.5rem;">
                Try increasing your search radius or check back later
            </p>
        </div>
        
        <?php endif; ?>
    </div>
</div>

<!-- User Details Modal -->
<div class="modal-overlay" id="userModal" onclick="closeModalOnOverlay(event)">
    <div class="modal-content">
        <div class="modal-header">
            <button class="modal-close" onclick="closeModal()">×</button>
            <div class="modal-user-avatar" id="modalAvatar">👤</div>
            <div class="modal-user-name" id="modalUsername">Username</div>
            <div class="modal-user-status" id="modalStatus">🟢 Online Now</div>
        </div>
        
        <div class="modal-body">
            <div class="modal-distance" id="modalDistance" style="display: none;">
                <div class="modal-distance-value" id="modalDistanceValue">--</div>
                <div class="modal-distance-label">away from you</div>
            </div>
            
            <div class="modal-section">
                <h3>📋 Profile Info</h3>
                <div class="modal-info-item">
                    <span class="modal-info-icon">📅</span>
                    <span class="modal-info-label">Joined:</span>
                    <span class="modal-info-value" id="modalJoined">--</span>
                </div>
                <div class="modal-info-item">
                    <span class="modal-info-icon">👁️</span>
                    <span class="modal-info-label">Last Seen:</span>
                    <span class="modal-info-value" id="modalLastSeen">--</span>
                </div>
            </div>
        </div>
        
        <div class="modal-actions">
            <a href="#" id="modalViewProfile" class="modal-btn modal-btn-secondary">
                👤 View Profile
            </a>
            <a href="#" id="modalMessage" class="modal-btn modal-btn-primary">
                💬 Send Message
            </a>
        </div>
    </div>
</div>

<script>
let currentRadius = <?php echo $current_user['search_radius'] ?? 50; ?>;
let currentLocation = {
    latitude: <?php echo $current_user['current_latitude'] ?? 'null'; ?>,
    longitude: <?php echo $current_user['current_longitude'] ?? 'null'; ?>
};

function requestLocation() {
    const btn = document.getElementById('locationBtn');
    btn.disabled = true;
    btn.textContent = '📍 Getting Location...';
    
    if(!navigator.geolocation) {
        alert('Geolocation is not supported by your browser');
        btn.disabled = false;
        btn.textContent = '📍 Update My Location';
        return;
    }
    
    navigator.geolocation.getCurrentPosition(
        (position) => {
            updateLocation(position.coords.latitude, position.coords.longitude, true);
        },
        (error) => {
            console.error('Geolocation error:', error);
            alert('Unable to get your location. Please enable location access in your browser.');
            btn.disabled = false;
            btn.textContent = '📍 Update My Location';
        },
        {enableHighAccuracy: true, timeout: 10000, maximumAge: 0}
    );
}

function updateLocation(latitude, longitude, autoDetected = false) {
    const formData = new FormData();
    formData.append('action', 'update_location');
    formData.append('latitude', latitude);
    formData.append('longitude', longitude);
    formData.append('auto_detected', autoDetected);
    
    fetch('/api/location.php', {
        method: 'POST',
        body: formData
    })
    .then(response => response.json())
    .then(data => {
        if(data.success) {
            currentLocation = {latitude, longitude};
            location.reload();
        } else {
            alert(data.error || 'Failed to update location');
        }
        
        const btn = document.getElementById('locationBtn');
        btn.disabled = false;
        btn.textContent = '📍 Update My Location';
    });
}

function updateRadius(value) {
    document.getElementById('radiusValue').textContent = value + ' km';
    currentRadius = value;
    
    clearTimeout(window.radiusTimeout);
    window.radiusTimeout = setTimeout(() => {
        loadNearbyUsers();
    }, 500);
}

function toggleDistanceVisibility(show) {
    const formData = new FormData();
    formData.append('action', 'toggle_distance');
    formData.append('show_distance', show);
    
    fetch('/api/location.php', {method: 'POST', body: formData});
}

function loadNearbyUsers() {
    if(!currentLocation.latitude) return;
    
    const grid = document.getElementById('usersGrid');
    const loading = document.getElementById('loadingState');
    const noResults = document.getElementById('noResults');
    const resultsCount = document.getElementById('resultsCount');
    
    grid.style.display = 'none';
    loading.style.display = 'block';
    noResults.style.display = 'none';
    
    const params = new URLSearchParams({
        action: 'get_nearby_users',
        radius: currentRadius,
        limit: 100
    });
    
    fetch('/api/location.php?' + params)
        .then(response => response.json())
        .then(data => {
            loading.style.display = 'none';
            
            if(data.success && data.users.length > 0) {
                displayUsers(data.users);
                resultsCount.textContent = `Found ${data.count} user${data.count !== 1 ? 's' : ''} within ${currentRadius}km`;
            } else {
                noResults.style.display = 'block';
                resultsCount.textContent = '';
            }
        })
        .catch(error => {
            console.error('Error loading nearby users:', error);
            loading.style.display = 'none';
            noResults.style.display = 'block';
        });
}

function displayUsers(users) {
    const grid = document.getElementById('usersGrid');
    grid.innerHTML = '';
    grid.style.display = 'grid';
    
    users.forEach(user => {
        const card = document.createElement('div');
        card.className = 'user-card';
        card.onclick = () => openUserModal(user);
        
        card.innerHTML = `
            ${user.show_distance ? `<div class="distance-badge">📍 ${user.distance_display}</div>` : ''}
            
            <div class="user-card-content">
                <div class="user-avatar-wrapper">
                    <div class="user-avatar">
                        👤
                        ${user.is_online ? '<span class="online-badge"></span>' : ''}
                    </div>
                </div>
                
                <div class="user-info">
                    <div class="user-name">${escapeHtml(user.username)}</div>
                    <div class="user-status">
                        ${user.is_online ? 
                            '🟢 Online Now' : 
                            (user.last_seen ? '⚪ Last seen ' + formatTime(user.last_seen) : '⚪ Offline')
                        }
                    </div>
                    <div class="user-meta">
                        Member since ${formatDate(user.created_at)}
                    </div>
                </div>
                
                <div class="user-actions">
                    <a href="/profile.php?id=${user.id}" class="action-btn" onclick="event.stopPropagation()">
                        👤 Profile
                    </a>
                    <a href="/messages-chat-simple.php?user=${user.id}" class="action-btn" onclick="event.stopPropagation()">
                        💬 Message
                    </a>
                </div>
            </div>
        `;
        
        grid.appendChild(card);
    });
}

function openUserModal(user) {
    document.getElementById('modalUsername').textContent = user.username;
    document.getElementById('modalStatus').innerHTML = user.is_online ? 
        '🟢 Online Now' : 
        (user.last_seen ? '⚪ Last seen ' + formatTime(user.last_seen) : '⚪ Offline');
    
    document.getElementById('modalJoined').textContent = formatDate(user.created_at);
    document.getElementById('modalLastSeen').textContent = user.last_seen ? formatTime(user.last_seen) : 'Unknown';
    
    if(user.show_distance && user.distance_display) {
        document.getElementById('modalDistance').style.display = 'block';
        document.getElementById('modalDistanceValue').textContent = user.distance_display;
    } else {
        document.getElementById('modalDistance').style.display = 'none';
    }
    
    document.getElementById('modalViewProfile').href = '/profile.php?id=' + user.id;
    document.getElementById('modalMessage').href = '/messages-chat-simple.php?user=' + user.id;
    
    document.getElementById('userModal').classList.add('active');
    document.body.style.overflow = 'hidden';
}

function closeModal() {
    document.getElementById('userModal').classList.remove('active');
    document.body.style.overflow = '';
}

function closeModalOnOverlay(event) {
    if(event.target.classList.contains('modal-overlay')) {
        closeModal();
    }
}

function escapeHtml(text) {
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
}

function formatTime(timestamp) {
    const date = new Date(timestamp);
    const now = new Date();
    const diff = now - date;
    
    if(diff < 60000) return 'just now';
    if(diff < 3600000) return Math.floor(diff / 60000) + 'm ago';
    if(diff < 86400000) return Math.floor(diff / 3600000) + 'h ago';
    if(diff < 604800000) return Math.floor(diff / 86400000) + 'd ago';
    
    return date.toLocaleDateString();
}

function formatDate(timestamp) {
    return new Date(timestamp).toLocaleDateString('en-US', { 
        year: 'numeric', 
        month: 'short' 
    });
}

if(currentLocation.latitude) {
    loadNearbyUsers();
    setInterval(() => {
        loadNearbyUsers();
    }, 30000);
}

document.addEventListener('keydown', function(e) {
    if(e.key === 'Escape') {
        closeModal();
    }
});
</script>

<?php include 'views/footer.php'; ?>