<?php
session_start();
require_once '../config/database.php';

$database = new Database();
$db = $database->getConnection();

// Check if logged in
if(!isset($_SESSION['user_id'])) {
    $_SESSION['redirect_after_login'] = $_SERVER['REQUEST_URI'];
    header('Location: /login.php');
    exit();
}

// Check if is_admin column exists and user is admin
try {
    $query = "SELECT is_admin FROM users WHERE id = :user_id LIMIT 1";
    $stmt = $db->prepare($query);
    $stmt->execute(['user_id' => $_SESSION['user_id']]);
    $user = $stmt->fetch();
    
    if(!$user || !$user['is_admin']) {
        // Not an admin
        echo '<!DOCTYPE html>
        <html>
        <head>
            <title>Access Denied</title>
            <style>
                body {
                    font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
                    display: flex;
                    align-items: center;
                    justify-content: center;
                    min-height: 100vh;
                    margin: 0;
                    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
                }
                .error-container {
                    background: white;
                    padding: 3rem;
                    border-radius: 20px;
                    text-align: center;
                    box-shadow: 0 20px 60px rgba(0,0,0,0.3);
                    max-width: 500px;
                }
                .error-icon {
                    font-size: 5rem;
                    margin-bottom: 1rem;
                }
                h1 {
                    color: #1e293b;
                    margin-bottom: 1rem;
                }
                p {
                    color: #64748b;
                    line-height: 1.6;
                }
                .btn {
                    display: inline-block;
                    margin-top: 2rem;
                    padding: 1rem 2rem;
                    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
                    color: white;
                    text-decoration: none;
                    border-radius: 10px;
                    font-weight: 600;
                }
            </style>
        </head>
        <body>
            <div class="error-container">
                <div class="error-icon">🔒</div>
                <h1>Access Denied</h1>
                <p>You do not have administrator privileges to access this page.</p>
                <p><strong>User ID:</strong> ' . $_SESSION['user_id'] . '</p>
                <p><strong>Username:</strong> ' . ($_SESSION['username'] ?? 'Unknown') . '</p>
                <a href="/" class="btn">Go to Homepage</a>
            </div>
        </body>
        </html>';
        exit();
    }
    
} catch(PDOException $e) {
    // Column doesn't exist
    echo '<!DOCTYPE html>
    <html>
    <head>
        <title>Setup Required</title>
        <style>
            body {
                font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
                display: flex;
                align-items: center;
                justify-content: center;
                min-height: 100vh;
                margin: 0;
                background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            }
            .setup-container {
                background: white;
                padding: 3rem;
                border-radius: 20px;
                text-align: center;
                box-shadow: 0 20px 60px rgba(0,0,0,0.3);
                max-width: 600px;
            }
            .setup-icon {
                font-size: 5rem;
                margin-bottom: 1rem;
            }
            h1 {
                color: #1e293b;
                margin-bottom: 1rem;
            }
            p {
                color: #64748b;
                line-height: 1.6;
                margin-bottom: 1rem;
            }
            .code-block {
                background: #1e293b;
                color: #10b981;
                padding: 1rem;
                border-radius: 10px;
                font-family: monospace;
                text-align: left;
                margin: 1.5rem 0;
                overflow-x: auto;
            }
            .btn {
                display: inline-block;
                margin-top: 1rem;
                padding: 1rem 2rem;
                background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
                color: white;
                text-decoration: none;
                border-radius: 10px;
                font-weight: 600;
            }
        </style>
    </head>
    <body>
        <div class="setup-container">
            <div class="setup-icon">⚙️</div>
            <h1>Admin Setup Required</h1>
            <p>The admin system needs to be initialized. Run this SQL command:</p>
            <div class="code-block">
ALTER TABLE users ADD COLUMN is_admin BOOLEAN DEFAULT FALSE;<br>
UPDATE users SET is_admin = TRUE WHERE username = \'inmate360\';
            </div>
            <p><strong>Or</strong> upload and run <code>make-admin.php</code> from your site root.</p>
            <a href="/" class="btn">Go Back</a>
        </div>
    </body>
    </html>';
    exit();
}

// Continue with rest of admin settings page...
$success = '';
$error = '';

// ... rest of your admin settings code from before ...
?>