<?php
session_start();
require_once '../config/database.php';

// Check if user is admin
if(!isset($_SESSION['user_id'])) {
    header('Location: ../login.php');
    exit();
}

$database = new Database();
$db = $database->getConnection();

// Check admin status
$query = "SELECT is_admin FROM users WHERE id = :user_id LIMIT 1";
$stmt = $db->prepare($query);
$stmt->bindParam(':user_id', $_SESSION['user_id']);
$stmt->execute();
$user = $stmt->fetch();

if(!$user || !$user['is_admin']) {
    header('Location: ../index.php');
    exit();
}

$success = '';
$error = '';

// Ensure reports table exists
try {
    $create_table = "CREATE TABLE IF NOT EXISTS reports (
        id INT AUTO_INCREMENT PRIMARY KEY,
        reporter_id INT NOT NULL,
        reported_type ENUM('listing', 'user', 'message') NOT NULL,
        reported_id INT NOT NULL,
        reason VARCHAR(100) NOT NULL,
        description TEXT,
        status ENUM('pending', 'resolved', 'dismissed') DEFAULT 'pending',
        action_taken TEXT,
        resolved_by INT NULL,
        resolved_at TIMESTAMP NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (reporter_id) REFERENCES users(id) ON DELETE CASCADE,
        FOREIGN KEY (resolved_by) REFERENCES users(id) ON DELETE SET NULL,
        INDEX idx_status (status),
        INDEX idx_reporter (reporter_id),
        INDEX idx_reported (reported_type, reported_id)
    )";
    $db->exec($create_table);
} catch(PDOException $e) {
    // Table might already exist
}

// Handle report actions
if($_SERVER['REQUEST_METHOD'] == 'POST') {
    if(isset($_POST['resolve_report'])) {
        $report_id = $_POST['report_id'];
        $action_taken = $_POST['action_taken'];
        
        $query = "UPDATE reports 
                  SET status = 'resolved', action_taken = :action, resolved_by = :admin_id, resolved_at = NOW()
                  WHERE id = :id";
        $stmt = $db->prepare($query);
        $stmt->bindParam(':action', $action_taken);
        $stmt->bindParam(':admin_id', $_SESSION['user_id']);
        $stmt->bindParam(':id', $report_id);
        
        if($stmt->execute()) {
            $success = 'Report resolved successfully!';
        } else {
            $error = 'Failed to resolve report';
        }
    }
    
    if(isset($_POST['dismiss_report'])) {
        $report_id = $_POST['report_id'];
        
        $query = "UPDATE reports 
                  SET status = 'dismissed', resolved_by = :admin_id, resolved_at = NOW()
                  WHERE id = :id";
        $stmt = $db->prepare($query);
        $stmt->bindParam(':admin_id', $_SESSION['user_id']);
        $stmt->bindParam(':id', $report_id);
        
        if($stmt->execute()) {
            $success = 'Report dismissed';
        }
    }
}

// Get pending reports
try {
    $query = "SELECT r.*, u.username as reporter_name
              FROM reports r
              LEFT JOIN users u ON r.reporter_id = u.id
              WHERE r.status = 'pending'
              ORDER BY r.created_at DESC";
    $stmt = $db->prepare($query);
    $stmt->execute();
    $pending_reports = $stmt->fetchAll();
} catch(PDOException $e) {
    error_log("Error fetching reports: " . $e->getMessage());
    $pending_reports = [];
}

// Get recent resolved reports
try {
    $query = "SELECT r.*, u.username as reporter_name, a.username as admin_name
              FROM reports r
              LEFT JOIN users u ON r.reporter_id = u.id
              LEFT JOIN users a ON r.resolved_by = a.id
              WHERE r.status IN ('resolved', 'dismissed')
              ORDER BY r.resolved_at DESC
              LIMIT 20";
    $stmt = $db->prepare($query);
    $stmt->execute();
    $recent_reports = $stmt->fetchAll();
} catch(PDOException $e) {
    error_log("Error fetching recent reports: " . $e->getMessage());
    $recent_reports = [];
}

include '../views/header.php';
?>

<link rel="stylesheet" href="../assets/css/dark-blue-theme.css">

<div class="admin-container">
    <div class="admin-header">
        <h1>🚨 Reports Management</h1>
        <p style="color: var(--text-gray);">Review and resolve user reports</p>
    </div>

    <div class="admin-nav">
        <a href="dashboard.php">📊 Dashboard</a>
        <a href="users.php">👥 Users</a>
        <a href="listings.php">📝 Listings</a>
        <a href="upgrades.php">💎 Upgrades</a>
        <a href="reports.php" class="active">🚨 Reports</a>
        <a href="announcements.php">📢 Announcements</a>
        <a href="categories.php">📁 Categories</a>
        <a href="settings.php">⚙️ Settings</a>
    </div>

    <?php if($success): ?>
    <div class="alert alert-success"><?php echo $success; ?></div>
    <?php endif; ?>
    
    <?php if($error): ?>
    <div class="alert alert-error"><?php echo $error; ?></div>
    <?php endif; ?>

    <div class="admin-section">
        <h2>⏳ Pending Reports (<?php echo count($pending_reports); ?>)</h2>
        
        <?php if(count($pending_reports) > 0): ?>
        <div style="overflow-x: auto;">
            <table class="data-table">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Reporter</th>
                        <th>Type</th>
                        <th>Reported ID</th>
                        <th>Reason</th>
                        <th>Description</th>
                        <th>Date</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach($pending_reports as $report): ?>
                    <tr>
                        <td><?php echo $report['id']; ?></td>
                        <td><?php echo htmlspecialchars($report['reporter_name']); ?></td>
                        <td>
                            <span class="category-badge" style="font-size: 0.75rem;">
                                <?php echo ucfirst($report['reported_type']); ?>
                            </span>
                        </td>
                        <td>
                            <?php if($report['reported_type'] == 'listing'): ?>
                            <a href="../listing.php?id=<?php echo $report['reported_id']; ?>" style="color: var(--primary-blue);" target="_blank">
                                View Listing
                            </a>
                            <?php elseif($report['reported_type'] == 'user'): ?>
                            <a href="../profile.php?id=<?php echo $report['reported_id']; ?>" style="color: var(--primary-blue);" target="_blank">
                                View User
                            </a>
                            <?php else: ?>
                            ID: <?php echo $report['reported_id']; ?>
                            <?php endif; ?>
                        </td>
                        <td>
                            <span style="color: var(--danger-red);">
                                <?php echo htmlspecialchars($report['reason']); ?>
                            </span>
                        </td>
                        <td>
                            <div style="max-width: 200px; overflow: hidden; text-overflow: ellipsis;">
                                <?php echo htmlspecialchars($report['description']); ?>
                            </div>
                        </td>
                        <td><?php echo date('M j, Y', strtotime($report['created_at'])); ?></td>
                        <td>
                            <button class="action-btn edit" onclick="showResolveModal(<?php echo $report['id']; ?>)">
                                Resolve
                            </button>
                            <form method="POST" style="display: inline;">
                                <input type="hidden" name="report_id" value="<?php echo $report['id']; ?>">
                                <button type="submit" name="dismiss_report" class="action-btn delete" onclick="return confirm('Dismiss this report?');">
                                    Dismiss
                                </button>
                            </form>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
        <?php else: ?>
        <div style="text-align: center; padding: 3rem; background: rgba(66, 103, 245, 0.05); border-radius: 10px;">
            <div style="font-size: 3rem; margin-bottom: 1rem;">✓</div>
            <h3>No Pending Reports</h3>
            <p style="color: var(--text-gray);">All reports have been reviewed</p>
        </div>
        <?php endif; ?>
    </div>

    <div class="admin-section">
        <h2>Recent Actions</h2>
        <div style="overflow-x: auto;">
            <table class="data-table">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Reporter</th>
                        <th>Type</th>
                        <th>Reason</th>
                        <th>Status</th>
                        <th>Action Taken</th>
                        <th>Resolved By</th>
                        <th>Date</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach($recent_reports as $report): ?>
                    <tr>
                        <td><?php echo $report['id']; ?></td>
                        <td><?php echo htmlspecialchars($report['reporter_name']); ?></td>
                        <td><?php echo ucfirst($report['reported_type']); ?></td>
                        <td><?php echo htmlspecialchars($report['reason']); ?></td>
                        <td>
                            <span style="color: <?php echo $report['status'] == 'resolved' ? 'var(--success-green)' : 'var(--text-gray)'; ?>">
                                <?php echo ucfirst($report['status']); ?>
                            </span>
                        </td>
                        <td><?php echo htmlspecialchars($report['action_taken'] ?? 'N/A'); ?></td>
                        <td><?php echo htmlspecialchars($report['admin_name']); ?></td>
                        <td><?php echo date('M j, Y', strtotime($report['resolved_at'])); ?></td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<!-- Resolve Modal -->
<div id="resolveModal" style="display: none; position: fixed; top: 0; left: 0; right: 0; bottom: 0; background: rgba(0,0,0,0.8); z-index: 9999; justify-content: center; align-items: center;">
    <div class="card" style="max-width: 500px; width: 90%;">
        <h3 style="margin-bottom: 1rem;">Resolve Report</h3>
        <form method="POST" id="resolveForm">
            <input type="hidden" name="report_id" id="resolveReportId">
            <div class="form-group">
                <label>Action Taken</label>
                <select name="action_taken" required>
                    <option value="">Select action...</option>
                    <option value="Content removed">Content removed</option>
                    <option value="User warned">User warned</option>
                    <option value="User suspended">User suspended</option>
                    <option value="User banned">User banned</option>
                    <option value="No action needed">No action needed</option>
                    <option value="Other">Other</option>
                </select>
            </div>
            <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 1rem;">
                <button type="button" class="btn-secondary btn-block" onclick="closeResolveModal()">Cancel</button>
                <button type="submit" name="resolve_report" class="btn-success btn-block">Resolve</button>
            </div>
        </form>
    </div>
</div>

<script>
function showResolveModal(reportId) {
    document.getElementById('resolveReportId').value = reportId;
    document.getElementById('resolveModal').style.display = 'flex';
}

function closeResolveModal() {
    document.getElementById('resolveModal').style.display = 'none';
}

document.getElementById('resolveModal').addEventListener('click', function(e) {
    if(e.target === this) {
        closeResolveModal();
    }
});
</script>

<?php include '../views/footer.php'; ?>