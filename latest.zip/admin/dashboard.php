<?php
session_start();
require_once '../config/database.php';

if(!isset($_SESSION['user_id'])) {
    header('Location: ../login.php');
    exit();
}

$database = new Database();
$db = $database->getConnection();

// Check admin status
$query = "SELECT is_admin FROM users WHERE id = :user_id LIMIT 1";
$stmt = $db->prepare($query);
$stmt->bindParam(':user_id', $_SESSION['user_id']);
$stmt->execute();
$admin = $stmt->fetch();

if(!$admin || !$admin['is_admin']) {
    header('Location: ../index.php');
    exit();
}

// Helper function to check if table exists
function tableExists($db, $tableName) {
    try {
        $result = $db->query("SHOW TABLES LIKE '{$tableName}'");
        return $result->rowCount() > 0;
    } catch(PDOException $e) {
        return false;
    }
}

// Helper function to check if column exists
function columnExists($db, $tableName, $columnName) {
    try {
        $result = $db->query("SHOW COLUMNS FROM {$tableName} LIKE '{$columnName}'");
        return $result->rowCount() > 0;
    } catch(PDOException $e) {
        return false;
    }
}

// Get basic statistics
$query = "SELECT 
    (SELECT COUNT(*) FROM users) as total_users,
    (SELECT COUNT(*) FROM users WHERE created_at >= DATE_SUB(NOW(), INTERVAL 30 DAY)) as new_users_month,
    (SELECT COUNT(*) FROM listings) as total_listings,
    (SELECT COUNT(*) FROM listings WHERE status = 'active') as active_listings,
    (SELECT COUNT(*) FROM listings WHERE created_at >= DATE_SUB(NOW(), INTERVAL 24 HOUR)) as listings_today,
    (SELECT COUNT(*) FROM messages) as total_messages,
    (SELECT COUNT(*) FROM messages WHERE created_at >= DATE_SUB(NOW(), INTERVAL 24 HOUR)) as messages_today";

// Add optional columns if they exist
if(columnExists($db, 'users', 'is_online')) {
    $query .= ", (SELECT COUNT(*) FROM users WHERE is_online = TRUE) as users_online";
}

if(tableExists($db, 'reports')) {
    $query .= ", (SELECT COUNT(*) FROM reports WHERE status = 'pending') as pending_reports";
}

if(tableExists($db, 'user_warnings')) {
    $query .= ", (SELECT COUNT(*) FROM user_warnings WHERE acknowledged = FALSE) as active_warnings";
}

if(tableExists($db, 'moderation_appeals')) {
    $query .= ", (SELECT COUNT(*) FROM moderation_appeals WHERE status = 'pending') as pending_appeals";
}

try {
    $stmt = $db->prepare($query);
    $stmt->execute();
    $stats = $stmt->fetch();
    
    // Set defaults for missing values
    $stats['users_online'] = $stats['users_online'] ?? 0;
    $stats['pending_reports'] = $stats['pending_reports'] ?? 0;
    $stats['active_warnings'] = $stats['active_warnings'] ?? 0;
    $stats['pending_appeals'] = $stats['pending_appeals'] ?? 0;
} catch(PDOException $e) {
    error_log("Error getting stats: " . $e->getMessage());
    $stats = [
        'total_users' => 0,
        'new_users_month' => 0,
        'users_online' => 0,
        'total_listings' => 0,
        'active_listings' => 0,
        'listings_today' => 0,
        'total_messages' => 0,
        'messages_today' => 0,
        'pending_reports' => 0,
        'active_warnings' => 0,
        'pending_appeals' => 0
    ];
}

// AI Moderation Stats (if tables exist)
$ai_stats = [
    'flagged_listings' => 0,
    'flagged_images' => 0,
    'flagged_text' => 0,
    'users_at_risk' => 0
];

if(columnExists($db, 'listings', 'moderation_status')) {
    try {
        $query = "SELECT 
            (SELECT COUNT(*) FROM listings WHERE moderation_status = 'flagged' OR auto_flagged = TRUE) as flagged_listings";
        
        if(tableExists($db, 'image_moderation')) {
            $query .= ", (SELECT COUNT(*) FROM image_moderation WHERE status = 'flagged') as flagged_images";
        }
        
        if(tableExists($db, 'text_moderation')) {
            $query .= ", (SELECT COUNT(*) FROM text_moderation WHERE status = 'flagged') as flagged_text";
        }
        
        if(tableExists($db, 'user_behavior_scores')) {
            $query .= ", (SELECT COUNT(*) FROM user_behavior_scores WHERE account_status = 'warning') as users_at_risk";
        }
        
        $stmt = $db->prepare($query);
        $stmt->execute();
        $ai_stats = array_merge($ai_stats, $stmt->fetch());
    } catch(PDOException $e) {
        error_log("Error getting AI stats: " . $e->getMessage());
    }
}

// Advertising Stats (if tables exist)
$ad_stats = [
    'active_premium' => 0,
    'active_sponsored' => 0,
    'active_banners' => 0,
    'impressions_today' => 0,
    'clicks_today' => 0
];

if(tableExists($db, 'premium_listings')) {
    try {
        $query = "SELECT 
            (SELECT COUNT(*) FROM premium_listings WHERE is_active = TRUE) as active_premium";
        
        if(tableExists($db, 'sponsored_profiles')) {
            $query .= ", (SELECT COUNT(*) FROM sponsored_profiles WHERE is_active = TRUE) as active_sponsored";
        }
        
        if(tableExists($db, 'banner_ads')) {
            $query .= ", (SELECT COUNT(*) FROM banner_ads WHERE is_active = TRUE) as active_banners";
        }
        
        if(tableExists($db, 'ad_impressions')) {
            $query .= ", (SELECT COUNT(*) FROM ad_impressions WHERE viewed_at >= DATE_SUB(NOW(), INTERVAL 24 HOUR)) as impressions_today";
        }
        
        if(tableExists($db, 'ad_clicks')) {
            $query .= ", (SELECT COUNT(*) FROM ad_clicks WHERE clicked_at >= DATE_SUB(NOW(), INTERVAL 24 HOUR)) as clicks_today";
        }
        
        $stmt = $db->prepare($query);
        $stmt->execute();
        $ad_stats = array_merge($ad_stats, $stmt->fetch());
    } catch(PDOException $e) {
        error_log("Error getting ad stats: " . $e->getMessage());
    }
}

// Revenue Stats (if tables exist)
$revenue_stats = [
    'revenue_premium_today' => 0,
    'revenue_sponsored_today' => 0,
    'revenue_ads_today' => 0,
    'revenue_premium_month' => 0,
    'revenue_sponsored_month' => 0
];

if(tableExists($db, 'premium_listings')) {
    try {
        $query = "SELECT 
            (SELECT COALESCE(SUM(cost), 0) FROM premium_listings WHERE DATE(created_at) = CURDATE()) as revenue_premium_today,
            (SELECT COALESCE(SUM(cost), 0) FROM premium_listings WHERE created_at >= DATE_SUB(NOW(), INTERVAL 30 DAY)) as revenue_premium_month";
        
        if(tableExists($db, 'sponsored_profiles')) {
            $query .= ", (SELECT COALESCE(SUM(cost), 0) FROM sponsored_profiles WHERE DATE(created_at) = CURDATE()) as revenue_sponsored_today,
                         (SELECT COALESCE(SUM(cost), 0) FROM sponsored_profiles WHERE created_at >= DATE_SUB(NOW(), INTERVAL 30 DAY)) as revenue_sponsored_month";
        }
        
        if(tableExists($db, 'ad_revenue')) {
            $query .= ", (SELECT COALESCE(SUM(revenue), 0) FROM ad_revenue WHERE revenue_date = CURDATE()) as revenue_ads_today";
        }
        
        $stmt = $db->prepare($query);
        $stmt->execute();
        $revenue_stats = array_merge($revenue_stats, $stmt->fetch());
    } catch(PDOException $e) {
        error_log("Error getting revenue stats: " . $e->getMessage());
    }
}

$total_revenue_today = $revenue_stats['revenue_premium_today'] + $revenue_stats['revenue_sponsored_today'] + $revenue_stats['revenue_ads_today'];
$total_revenue_month = $revenue_stats['revenue_premium_month'] + $revenue_stats['revenue_sponsored_month'];

// Recent activity
try {
    $query = "SELECT 'user' as type, username as title, created_at 
              FROM users 
              WHERE created_at >= DATE_SUB(NOW(), INTERVAL 24 HOUR)
              UNION ALL
              SELECT 'listing' as type, title, created_at 
              FROM listings 
              WHERE created_at >= DATE_SUB(NOW(), INTERVAL 24 HOUR)
              ORDER BY created_at DESC 
              LIMIT 10";
    $stmt = $db->prepare($query);
    $stmt->execute();
    $recent_activity = $stmt->fetchAll();
} catch(PDOException $e) {
    error_log("Error getting recent activity: " . $e->getMessage());
    $recent_activity = [];
}

// Top performing ads
$top_ads = [];
if(tableExists($db, 'premium_listings')) {
    try {
        $query = "SELECT 'premium' as type, l.title, pl.current_impressions as impressions, pl.clicks
                  FROM premium_listings pl
                  LEFT JOIN listings l ON pl.listing_id = l.id
                  WHERE pl.is_active = TRUE
                  ORDER BY pl.clicks DESC
                  LIMIT 5";
        $stmt = $db->prepare($query);
        $stmt->execute();
        $top_ads = $stmt->fetchAll();
    } catch(PDOException $e) {
        error_log("Error getting top ads: " . $e->getMessage());
    }
}

include '../views/header.php';
?>

<link rel="stylesheet" href="../assets/css/dark-blue-theme.css">

<style>
.admin-dashboard {
    max-width: 1600px;
    margin: 2rem auto;
    padding: 0 20px;
}

.dashboard-header {
    margin-bottom: 2rem;
    padding-bottom: 1rem;
    border-bottom: 2px solid var(--border-color);
}

.quick-actions {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
    gap: 1rem;
    margin-bottom: 2rem;
}

.quick-action-btn {
    background: linear-gradient(135deg, var(--primary-blue), var(--secondary-blue));
    padding: 1.5rem;
    border-radius: 12px;
    text-align: center;
    color: white;
    text-decoration: none;
    transition: all 0.3s;
    border: 2px solid transparent;
}

.quick-action-btn:hover {
    transform: translateY(-3px);
    border-color: var(--featured-gold);
    box-shadow: 0 10px 30px rgba(66, 103, 245, 0.3);
}

.quick-action-icon {
    font-size: 2rem;
    margin-bottom: 0.5rem;
}

.stats-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
    gap: 1.5rem;
    margin-bottom: 2rem;
}

.stat-card {
    background: var(--card-bg);
    border: 2px solid var(--border-color);
    border-radius: 12px;
    padding: 1.5rem;
    transition: all 0.3s;
}

.stat-card:hover {
    border-color: var(--primary-blue);
    transform: translateY(-2px);
}

.stat-card.warning {
    border-color: var(--warning-orange);
    background: rgba(245, 158, 11, 0.05);
}

.stat-card.danger {
    border-color: var(--danger-red);
    background: rgba(239, 68, 68, 0.05);
}

.stat-card.success {
    border-color: var(--success-green);
    background: rgba(16, 185, 129, 0.05);
}

.stat-label {
    color: var(--text-gray);
    font-size: 0.9rem;
    margin-bottom: 0.5rem;
}

.stat-value {
    font-size: 2.5rem;
    font-weight: bold;
    color: var(--text-white);
}

.stat-change {
    font-size: 0.85rem;
    margin-top: 0.5rem;
}

.stat-change.positive {
    color: var(--success-green);
}

.dashboard-section {
    background: var(--card-bg);
    border: 2px solid var(--border-color);
    border-radius: 12px;
    padding: 1.5rem;
    margin-bottom: 2rem;
}

.section-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 1.5rem;
    padding-bottom: 1rem;
    border-bottom: 1px solid var(--border-color);
}

.section-header h2 {
    margin: 0;
    color: var(--primary-blue);
}

.activity-list {
    list-style: none;
    padding: 0;
}

.activity-item {
    padding: 0.75rem;
    margin: 0.5rem 0;
    background: rgba(66, 103, 245, 0.05);
    border-left: 3px solid var(--primary-blue);
    border-radius: 8px;
}

.charts-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(400px, 1fr));
    gap: 1.5rem;
}

.setup-notice {
    background: rgba(245, 158, 11, 0.1);
    border: 2px solid var(--warning-orange);
    border-radius: 12px;
    padding: 1.5rem;
    margin-bottom: 2rem;
}

@media (max-width: 768px) {
    .stats-grid {
        grid-template-columns: 1fr;
    }
    
    .charts-grid {
        grid-template-columns: 1fr;
    }
}
</style>

<div class="page-content">
    <div class="admin-dashboard">
        <div class="dashboard-header">
            <h1>🎛️ Admin Dashboard</h1>
            <p style="color: var(--text-gray);">
                Welcome back, <?php echo htmlspecialchars($_SESSION['username'] ?? 'Admin'); ?> • 
                <?php echo date('l, F j, Y g:i A'); ?>
            </p>
        </div>

        <?php if(!tableExists($db, 'premium_listings') || !tableExists($db, 'moderation_logs')): ?>
        <div class="setup-notice">
            <h3 style="color: var(--warning-orange); margin-bottom: 1rem;">⚠️ Setup Required</h3>
            <p style="margin-bottom: 1rem;">
                Some advanced features require additional database tables. Run the following SQL files to enable all features:
            </p>
            <ul style="line-height: 2; margin-left: 1.5rem;">
                <?php if(!tableExists($db, 'premium_listings')): ?>
                <li><code>database/advertising_system.sql</code> - Enable advertising features</li>
                <?php endif; ?>
                <?php if(!tableExists($db, 'moderation_logs')): ?>
                <li><code>database/content_moderation.sql</code> - Enable AI moderation</li>
                <?php endif; ?>
            </ul>
            <p style="margin-top: 1rem; font-size: 0.9rem; color: var(--text-gray);">
                The platform will continue to work without these features, but you'll have limited functionality.
            </p>
        </div>
        <?php endif; ?>

        <!-- Quick Actions -->
        <div class="quick-actions">
            <a href="/admin/users.php" class="quick-action-btn">
                <div class="quick-action-icon">👥</div>
                <div>Manage Users</div>
            </a>
            <?php if(tableExists($db, 'moderation_logs')): ?>
            <a href="/moderator/ai-moderation.php" class="quick-action-btn">
                <div class="quick-action-icon">🤖</div>
                <div>AI Moderation</div>
            </a>
            <?php endif; ?>
            <?php if(tableExists($db, 'premium_listings')): ?>
            <a href="/admin/advertising.php" class="quick-action-btn">
                <div class="quick-action-icon">📊</div>
                <div>Advertising</div>
            </a>
            <?php endif; ?>
            <?php if(tableExists($db, 'reports')): ?>
            <a href="/admin/reports.php" class="quick-action-btn">
                <div class="quick-action-icon">🚨</div>
                <div>Reports<?php echo $stats['pending_reports'] > 0 ? " ({$stats['pending_reports']})" : ''; ?></div>
            </a>
            <?php endif; ?>
            <a href="/admin/settings.php" class="quick-action-btn">
                <div class="quick-action-icon">⚙️</div>
                <div>Site Settings</div>
            </a>
        </div>

        <!-- Main Stats -->
        <h2 style="margin-bottom: 1rem;">📈 Platform Overview</h2>
        <div class="stats-grid">
            <div class="stat-card">
                <div class="stat-label">Total Users</div>
                <div class="stat-value"><?php echo number_format($stats['total_users']); ?></div>
                <div class="stat-change positive">
                    +<?php echo number_format($stats['new_users_month']); ?> this month
                </div>
            </div>
            
            <div class="stat-card success">
                <div class="stat-label">Users Online</div>
                <div class="stat-value"><?php echo number_format($stats['users_online']); ?></div>
                <div class="stat-change">Currently active</div>
            </div>
            
            <div class="stat-card">
                <div class="stat-label">Total Listings</div>
                <div class="stat-value"><?php echo number_format($stats['total_listings']); ?></div>
                <div class="stat-change positive">
                    +<?php echo number_format($stats['listings_today']); ?> today
                </div>
            </div>
            
            <div class="stat-card">
                <div class="stat-label">Active Listings</div>
                <div class="stat-value"><?php echo number_format($stats['active_listings']); ?></div>
                <div class="stat-change">
                    <?php echo $stats['total_listings'] > 0 ? round(($stats['active_listings'] / $stats['total_listings']) * 100) : 0; ?>% of total
                </div>
            </div>
            
            <div class="stat-card">
                <div class="stat-label">Messages</div>
                <div class="stat-value"><?php echo number_format($stats['total_messages']); ?></div>
                <div class="stat-change positive">
                    +<?php echo number_format($stats['messages_today']); ?> today
                </div>
            </div>
            
            <?php if(tableExists($db, 'reports')): ?>
            <div class="stat-card <?php echo $stats['pending_reports'] > 0 ? 'warning' : ''; ?>">
                <div class="stat-label">Pending Reports</div>
                <div class="stat-value"><?php echo number_format($stats['pending_reports']); ?></div>
                <div class="stat-change">Requires review</div>
            </div>
            <?php endif; ?>
        </div>

        <?php if(tableExists($db, 'moderation_logs')): ?>
        <!-- AI Moderation Stats -->
        <h2 style="margin-bottom: 1rem;">🤖 AI Moderation Status</h2>
        <div class="stats-grid">
            <div class="stat-card <?php echo $ai_stats['flagged_listings'] > 0 ? 'danger' : 'success'; ?>">
                <div class="stat-label">Flagged Listings</div>
                <div class="stat-value"><?php echo number_format($ai_stats['flagged_listings']); ?></div>
                <div class="stat-change">
                    <a href="/moderator/ai-moderation.php" style="color: var(--primary-blue);">Review Now →</a>
                </div>
            </div>
            
            <div class="stat-card <?php echo $ai_stats['flagged_images'] > 0 ? 'warning' : 'success'; ?>">
                <div class="stat-label">Flagged Images</div>
                <div class="stat-value"><?php echo number_format($ai_stats['flagged_images']); ?></div>
                <div class="stat-change">NSFW Detection</div>
            </div>
            
            <div class="stat-card <?php echo $ai_stats['flagged_text'] > 0 ? 'warning' : 'success'; ?>">
                <div class="stat-label">Flagged Text</div>
                <div class="stat-value"><?php echo number_format($ai_stats['flagged_text']); ?></div>
                <div class="stat-change">Content Analysis</div>
            </div>
            
            <div class="stat-card <?php echo $ai_stats['users_at_risk'] > 0 ? 'warning' : 'success'; ?>">
                <div class="stat-label">Users At Risk</div>
                <div class="stat-value"><?php echo number_format($ai_stats['users_at_risk']); ?></div>
                <div class="stat-change">Behavior Detection</div>
            </div>
        </div>
        <?php endif; ?>

        <?php if(tableExists($db, 'premium_listings')): ?>
        <!-- Advertising & Revenue Stats -->
        <h2 style="margin-bottom: 1rem;">💰 Advertising & Revenue</h2>
        <div class="stats-grid">
            <div class="stat-card success">
                <div class="stat-label">Revenue Today</div>
                <div class="stat-value">$<?php echo number_format($total_revenue_today, 2); ?></div>
                <div class="stat-change">All sources</div>
            </div>
            
            <div class="stat-card success">
                <div class="stat-label">Revenue This Month</div>
                <div class="stat-value">$<?php echo number_format($total_revenue_month, 2); ?></div>
                <div class="stat-change positive">On track</div>
            </div>
            
            <div class="stat-card">
                <div class="stat-label">Premium Listings</div>
                <div class="stat-value"><?php echo number_format($ad_stats['active_premium']); ?></div>
                <div class="stat-change">Active now</div>
            </div>
            
            <div class="stat-card">
                <div class="stat-label">Ad Impressions Today</div>
                <div class="stat-value"><?php echo number_format($ad_stats['impressions_today']); ?></div>
                <div class="stat-change"><?php echo number_format($ad_stats['clicks_today']); ?> clicks</div>
            </div>
        </div>
        <?php endif; ?>

        <div class="charts-grid">
            <!-- Recent Activity -->
            <div class="dashboard-section">
                <div class="section-header">
                    <h2>📋 Recent Activity</h2>
                    <span style="color: var(--text-gray); font-size: 0.9rem;">Last 24 hours</span>
                </div>
                
                <?php if(count($recent_activity) > 0): ?>
                <ul class="activity-list">
                    <?php foreach($recent_activity as $activity): ?>
                    <li class="activity-item">
                        <div style="display: flex; justify-content: space-between;">
                            <span>
                                <?php echo $activity['type'] == 'user' ? '👤' : '📝'; ?>
                                <?php echo htmlspecialchars($activity['title']); ?>
                            </span>
                            <span style="color: var(--text-gray); font-size: 0.85rem;">
                                <?php echo date('g:i A', strtotime($activity['created_at'])); ?>
                            </span>
                        </div>
                    </li>
                    <?php endforeach; ?>
                </ul>
                <?php else: ?>
                <p style="text-align: center; color: var(--text-gray); padding: 2rem;">
                    No recent activity
                </p>
                <?php endif; ?>
            </div>

            <!-- System Health -->
            <div class="dashboard-section">
                <div class="section-header">
                    <h2>🏥 System Health</h2>
                </div>
                
                <div style="display: grid; gap: 1rem;">
                    <div style="padding: 1rem; background: rgba(16, 185, 129, 0.1); border-radius: 8px;">
                        <div style="color: var(--success-green); font-weight: bold;">✓ Database</div>
                        <div style="color: var(--text-gray); font-size: 0.9rem;">Connected & Operational</div>
                    </div>
                    <div style="padding: 1rem; background: rgba(16, 185, 129, 0.1); border-radius: 8px;">
                        <div style="color: var(--success-green); font-weight: bold;">✓ File System</div>
                        <div style="color: var(--text-gray); font-size: 0.9rem;">Writable</div>
                    </div>
                    <?php if(tableExists($db, 'moderation_logs')): ?>
                    <div style="padding: 1rem; background: rgba(16, 185, 129, 0.1); border-radius: 8px;">
                        <div style="color: var(--success-green); font-weight: bold;">✓ AI Moderation</div>
                        <div style="color: var(--text-gray); font-size: 0.9rem;">Active & Monitoring</div>
                    </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>

<?php include '../views/footer.php'; ?>